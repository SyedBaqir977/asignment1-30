// var age = ("I am 20 years old");
// alert (age);

// var num = ("You have visited this sites 14 times");
// alert (num);

// var birthyear = ("My birth year is " + 2001 + "\n" + "Data type of my declared variable is number"); 
// alert(birthyear);

var visitorname = prompt("Enter your nam");
var storetitle = prompt("Which store you want to shop");
var quantity = prompt("Enter the quantity");

console.log(visitorname + " ordered " + quantity + " T-shirt(s) " + storetitle + "Clothing store" );

