var username = ("");
var Myname = ("Syed Huzaifa");
alert(Myname)

var message = ("Hello World");
alert(message);

var namee = ("Jhone Doe");
alert(namee);
var age = ("15 years old");
alert(age);
var course = ("Certified Mobile Application Development");
alert(course);



var msg = ("PIZZA" + "\n" + "PIZZ" + "\n" + "PIZ"+ "\n" + "PI" + "\n" + "P");
alert(msg);


var email = ("My email address is " + "syedhuzaifa11222344@gmail.com");
alert(email);


var book = ("I am trying to learn from the book A Smarter Way To Learn JavaScript");
alert(book);

var content = ("Yah! i can write HTML content thorugh JavaScript");
console.log(content);

var design = ("▬▬▬▬▬▬▬▬▬ஜ ۩۞۩ ஜ▬▬▬▬▬▬▬▬▬");
alert(design);