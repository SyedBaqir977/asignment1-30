var variable1 = "Hello world";
var variable2 = "testing";
var variable3 = "multiple variables";

var one_statement = variable1 + variable2 + variable3;
alert(one_statement);


// five legal variable naam

// var variable_one =""
// var variable_two =""
// var variable_three =""
// var variable_four =""
// var variable_five =""

// five illegal variable naam

// var var = ""
// var act/upon = ""
// var 12illegal = ""
// var acb`vb = ""
// var aa = ""


var variables_name = ("Rules for naming JS variables" + "\n" + "variabls name can only contain numbers, $ and . for example $my_1stVarialbe" + "\n" + "Variable must begin with a letter, $ or _ For Example: $name_name or name" + "\n" + "Variables name are case sensitive" + "\n" + "variables name should not be JS keywords");

alert(variables_name);
