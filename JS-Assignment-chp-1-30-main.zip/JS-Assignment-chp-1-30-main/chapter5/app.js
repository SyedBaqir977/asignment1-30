// var num1 = prompt("Enter first number");
// num1 = +num1;
// var num2 = prompt("Enter second number");
// num2 = +num2;

// var add = ( num1 + num2 );
// var answer = ("the sum of" + num1 + "and" + num2 + "is" + add);
// alert(answer);


// var num1 = prompt("Enter first number");
// var num2 = prompt("Enter second number");

// var dif = (num1 - num2);
// console.log(dif);


