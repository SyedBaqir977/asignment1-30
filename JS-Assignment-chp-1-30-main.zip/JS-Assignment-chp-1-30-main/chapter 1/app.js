// First alert message
var line1 = "JavaScript Alert";
var line2 = "Error! please enter a valid password";

var message = line1 + "\n" + "\n" + line2;
alert(message);

// Second alert message
var line1 = "JavaScript Alert";
var line2 = "Welcome to JS land...";
var line3 = "Happy Coding";

var message = line1 + "\n" + "\n" + line2 + "\n"   + line3;
alert(message);

// Third alert message
var line1 = "JavaScript Alert";
var line2 = ("Welcome to JS land...");
var message = line1 + "\n" + "\n" + line2;
alert(message);

// Fourth alert message
var line1 = "JavaScript Alert";
var line2 = ("Happy Coding");
var line3 = ("Prevent this message from creating additional dialogues");

var message = line1 + "\n" + "\n" + line2 + "\n"   + line3;
alert(message);

// Fifth alert message
var line1 = "JavaScript Alert";
var line2 = "Hello... I can run JS through my web browser's console";

var message = line1 + "\n" + "\n" + line2;
console.log(message);







