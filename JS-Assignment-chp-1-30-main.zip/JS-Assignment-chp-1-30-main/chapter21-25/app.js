//___QUESTION NO 1___//

// var firstName=prompt("Enter tour first name")
// var lastName=prompt("Enter your last name")
// document.write(firstName + " " + lastName)

//___QUESTION NO 2___//

// var phone=prompt("Enter name of your fav phone")
// document.write("My favourite phone is : " + phone)
// var length = phone.length
// document.write( "</br> length of the string is : " + length)

//___QUESTION NO 3___//

// var string=prompt("Enter value which has word n","Pakistan")
// document.write("string : " + string)
// var index = string.indexOf("n")
// document.write("</br>Index of 'n' : "+index)

//___QUESTION NO 4___//

// var string=prompt("Enter value which has word l","Hello World")
// document.write("string : " + string)
// var index = string.lastIndexOf("l")
// document.write("</br>Index of 'l' : "+index)

//___QUESTION NO 5___//

// var pakistan=prompt("Enter value","Pakistani")
// document.write("string : " + pakistan)
// var char = pakistan.charAt(3)
// document.write("</br> Character at index 3 : " + char)

//___QUESTION NO 6___//

// var firstName=prompt("Enter tour first name")
// var lastName=prompt("Enter your last name")
// var fullName = firstName.concat(" ",lastName)
// document.write(fullName)

//___QUESTION NO 7___//

// var city = "Hyderabad"
// document.write("City : " + city )
// var afterReplacement = city.replace("Hyder","Islam")
// document.write("</br> After replacement : " + afterReplacement)

//___QUESTION NO 8___//

// var message = "Ali and Sammi are best friends. They play cricket and football together";
// document.write("Before edit : " + message)
// var newMessage  = message.replaceAll("and","&")
// document.write("</br>After edit : " + newMessage)

//___QUESTION NO 9___//

// var data = "472";
// document.write("value : " + data);
// document.write("</br>Type : " + typeof data + "</br>")
// document.write("value : " + data)
// document.write("</br>Type : " + typeof +data)

//___QUESTION NO 10___//

// var capital = prompt("Enter value")
// document.write("User Input : " + capital)
// var result = capital.toUpperCase()
// document.write("</br> Upper case : " + result)

//___QUESTION NO 11___//

// var lowercase = prompt("Enter Word : ", "pakistan")
// document.write("User Input : " + lowercase + "</br>")
// var result = lowercase.charAt(0).toUpperCase()
// var remain=lowercase.slice(1)
// document.write("Title Case : " + result + remain) 

//___QUESTION NO 12___//

// var number = 35.36
// document.write("Number : " + number)
// let result = number.toString().replace(".", "")
// document.write("</br> Result : "+result)


//____QUESTION NO 13___//

// var username = prompt("Enter username")
// for (let i = 0; i < username.length; i++) {

//     let alpha = username[i].charCodeAt(0)
//     if ([33, 44, 46, 64].includes(alpha)) {
//         alert('please ')
//         break
//     }
// }

//___QUESTION NO 14___//

// var A = ["cake", "apple pie", "cookie", "chips", "patties"]
// var need = prompt("Welcome to ABC backery What do you want to order Sir/MAm").toLowerCase()

// if (A.includes(need)) {
//     document.write(need + ' is found at index ' + A.indexOf(need));
// }
// else {
//     document.write("We are sorry. " + need + " is not available at our bakery")
// }

//___QUESTION NO 15__//



//___QUESTION NO 16___//

// var uni = "University of Karachi";
// uni = uni.split("")

// for (let i = 0; i < uni.length; i++) {
//     document.write(uni[i] + "</br>")  

// }

//___QUESTION NO 17___// 

// let input = prompt("Enter word", "pakistan")
// document.write("User Input : " + input)
// input = input.split("")
// document.write("</br>Last Character of input : " + input[input.length - 1])