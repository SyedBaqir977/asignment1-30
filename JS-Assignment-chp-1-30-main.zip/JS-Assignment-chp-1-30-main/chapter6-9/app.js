// var a = 10;
// alert("the value of a is " + a );

// b = ++a;
// alert("the value of ++a is " + b);

// alert("now the value of a is " + a);

// b = a++;
// alert("Now the value of a++ is " + a);

// alert("Now the value of a is " + a);

// b = --a;
// alert("the value of --a is" + b);
// alert("Now the value of a is" + a);

// b = a--
// aleret("the value of a-- is: " + b);
// alert("Now the value of a is: " + a);


// var a = 2, b=1;
// var result = --a - --b + ++b +b--;
// alert(result);

// --a = 2-1 = 1
// --a - --b = 1 - 0 = 1

// --a - --b + ++b + b-- 
//     = 1 +  2  + 0
//      =    3 Answer



// var greet = prompt("enter your name");
// alert("Welcome");



// var English = prompt("Enter Your English Marks");
// English = +English
// var Urdu = prompt("Enter Your Urdu Marks");
// Urdu= +Urdu
// var Math = prompt("Enter Your Math Marks");
// Math = +Math
// var percentage = ((English + Urdu + Math)*100/300)
// alert(percentage);



