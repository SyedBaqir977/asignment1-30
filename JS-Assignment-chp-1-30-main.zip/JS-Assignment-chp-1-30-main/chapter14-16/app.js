//___QUESTION NO 1___//

// var student = []

//___QUESTION NO 2__//

// var object = []

//__QUESTION NO 3__//

// var array = ["Hello"]
// var array = ["1234"]
// var array = [true]
// var array = ["hello" , 1234 ,true,]

//__QUESTION NO 7__//

// var Qualification = ["SSC", "HSC", "BCS", "BS", "BCOM", "Ms", "M. Phil.", "PhD"]

// document.write("<h3>Qualifications : </h3>")
// document.write(Qualification[0])
// document.write("<br>")
// document.write(Qualification[1])
// document.write("<br>")
// document.write(Qualification[2])
// document.write("<br>")
// document.write(Qualification[3])
// document.write("<br>")
// document.write(Qualification[4])
// document.write("<br>")
// document.write(Qualification[5])
// document.write("<br>")
// document.write(Qualification[6])
// document.write("<br>")
// document.write(Qualification[7])
// document.write("<br>")

//__QUESTION NO 8__//

// var students = ["Ahad", "Faiq", "Shahzaib"]
// var marks = [480, 470, 465]

// document.write(
//     "score  of  " + students[0] + " is " + marks[0] + " whose percentage is " + marks[0] * 100 / 500
// )
// document.write("<br>")
// document.write(
//     "score  of  " + students[1] + " is " + marks[1] + " whose percentage is " + marks[1] * 100 / 500
// )
// document.write("<br>")
// document.write(
//     "score  of  " + students[2] + " is " + marks[2] + " whose percentage is " + marks[2] * 100 / 500
// )
// document.write("<br>")

//__QUESTION NO 9__//

// var colors = ["red ", "yellow ", "green "]
// document.write(colors)
// colors.unshift("<br>" + prompt("Enter color", "pink "))
// document.write(colors)
// colors.push(prompt("Enter color", "Purple "))
// document.write(colors + "<br />")
// colors.unshift(prompt("Enter color", "Sky "))
// colors.unshift(prompt("Enter color", "Blue "))
// document.write(colors)
// colors.shift()
// document.write("<br>" + colors)
// colors.pop()
// document.write("<br>" + colors)
// var color1 = prompt("Enter color", "Black");
// var index = prompt("Enter Index", "2")
// colors.splice(index, 0, color1)
// document.write("<br>" + colors)
// var RemoveIndex = prompt("Enter Number", "1")
// var RemoveIndex2 = prompt("Enter Number", "2")
// colors.splice(RemoveIndex + RemoveIndex2)
// document.write("<br>" + colors)

//__QUESTION NO 10__//

// var score = [320, 230, 480, 120]
// document.write("Score of Student : " + score + "<br>")
// score.sort()
// document.write( "Oredered Score of Students : " + score)

//__QUESTION NO 11__//

// var city = ["karachi ", "Lahore ", "Islamabad", "Quetta", "Peshawar "]
// document.write("<h4>Cities List : </h4>")
// document.write(city)
// var selectedcities;
// document.write("<h4>Selected Cites : </h4>")
// document.write(city[2] + "," + city[3] )

//__QUESTION NO 12__//

// var cat = ["this", "is", "my", "cat"]
// document.write(cat + "<br>")
// document.write(cat.join(" "))

//__QUESTION NO 13__//

// var order = ["Keyboard","Mouse","Printer","Monitor"]

// document.write("Devices: <br>" + order + "<br>")

// document.write("Out: <br> " + order[0] + "<br>")
// document.write("Out: <br> " + order[1] + "<br>")
// document.write("Out: <br> " + order[2] + "<br>")
// document.write("Out: <br> " + order[3] + "<br>")

//__QUESTION NO 14__//

// var order1 = ["Keyboard","Mouse","Printer","Monitor"]

// document.write("Devices: <br>" + order1+ "<br>")

// document.write("Out: <br> " + order1[3] + "<br>")
// document.write("Out: <br> " + order1[2] + "<br>")
// document.write("Out: <br> " + order1[1] + "<br>")
// document.write("Out: <br> " + order1[0] + "<br>")

//__QUESTION NO 15__//

// var mobile = ["Apple", "Samsung", "Motorola", "Huawei", "Nokia", "Sony", "Haier"]
// document.write(
// "<select class=mobile>" +
//     " <option>apple<option>" +
//     " <option>Samsung<option>" +
//     " <option>Motorola<option>" +
//     " <option>Huawei<option>" +
//     " <option>Nokia<option>" +
//     " <option>Sony<option>" +
//     " <option>Haier<option>" +
// "</select>"    
// )