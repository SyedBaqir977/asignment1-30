//___CHAPTER 17--20___//


//___QUESTION NO 1___//

// var mutlidimensional = [[1, 2], [3, 4], [5, 6]]

//__QUESTION NO 2__//

// var multi= [[0,1,2,3],[1,0,1,2],[2,1,0,1]]
// document.write("<h1>" + multi[0] + "</h1>")
// document.write("<h1>" + multi[1] + "</h1>")
// document.write("<h1>" + multi[2] + "</h1>")

//__QUESTION NO 3__//

// for (var i = 1; i <= 10; i++) {
//     document.write(i);
// }

//__QUESTION NO 4__//

// var number = prompt("Enter a Number : ")
// var length = prompt("Enter length of multiplication table : ")
// var result;
// document.write("Multiplication table of " + number + " length " + length + "</br>")
// for (i = 1; i <= length; i++) {
//     result = number * i
//     document.write(number + " x " + i + " = " + result + "</br>")
// }

//__QUESTION NO 5__//

// var fruits = ["apple", "mango", "banana", "strawberry", "orange"]
// for (var i = 0; i < fruits.length; i++) {
//     document.write(fruits[i] + "</br>")
// }
// for (var j = 0; j < 1; j++) {
//     for (var k = 0; k < fruits.length; k++){
//         document.write("Element at index " + k + " is " + fruits[k] + "</br>")
//     }

// }

//__QUESTION NO 6__//

// var lastvalue = +prompt("Type Last Number");
// var firstvalue = +prompt("Type First NUmber")
// document.write("Counting : ")

// for (var i = firstvalue; i <= lastvalue; i++) {
//     document.write(i + ",")
// }
// document.write("</br>" + "Reverse Counting : ")
// for (var j = LengthOfCounting; j >= StartOfCounting; j--) {
//     document.write(j + ",");
// }
// document.write("</br>" + "Even Counting : ")
// var End = prompt("Enter Ending Even Number")
// for (var k = 0; k <= End; k += 2) {
//     document.write(k + ",")
// }
// document.write("</br>" + "Odd Counting : ")
// var End = prompt("Enter Ending Odd Number")
// for (var l = 1; l <= End; l += 2) {
//     document.write(l + ",")
// }
// document.write("</br>" + "Series Counting : ")
// End=20;
// for (var m = 0; m <= End; m += 2) {
//     document.write(m + "k ,")
// }

//__QUESTION NO 7__//

// var A = ["cake", "apple pie", "cookie", "chips", "patties"]
// var need = prompt("Welcome to ABC backery What do you want to order Sir/MAm")
// for (var i = 0 ;i <= A.length;i++){
//     if (A[i] === need) {
//         document.write(need + ' is found at index ' + i);
//         break;
//       }
// }

